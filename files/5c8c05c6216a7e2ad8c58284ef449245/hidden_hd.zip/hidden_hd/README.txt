PwnyOS was written for UIUCTF 2021 by ravi (jprx). Find out more about PwnyOS at www.pwnyos.com!

DISCLAIMER:
PwnyOS is an operating system designed to be insecure, buggy, and vulnerable. Throughout this 
challenge, you may gain access to the PwnyOS ISO image and kernel binary. Booting this 
operating system may result in permanent damage to your computer, motherboard, CPU, or 
firmware, or may result in permanent data loss. The authors take no responsibility for any damages 
caused by the software. The intention is that the PwnyOS image is analyzed statically or run under 
an emulator- never booted directly onto bare hardware. The authors assume no responsibility for 
any damages caused by the software, even when running the OS under an emulator. Users should 
only run the OS at their own risk. 
