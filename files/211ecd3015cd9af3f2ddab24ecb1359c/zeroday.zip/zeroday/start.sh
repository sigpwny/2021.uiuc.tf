#!/bin/bash
qemu-system-i386 -snapshot -cdrom PwnyOS.iso -monitor none -serial stdio -vga none -parallel none
